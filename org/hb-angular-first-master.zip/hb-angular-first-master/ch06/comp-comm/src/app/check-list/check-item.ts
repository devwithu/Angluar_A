export interface CheckItem {
    idx: number;
    content: string;
    isChecked: boolean;
}
