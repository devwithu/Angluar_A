# 주요 변경사항

## (2017-07-24) Material2 버전 호환성 반영
* Material2 의 beta.8에 cdk 패키지가 의존성으로 추가됨 [링크](https://github.com/angular/material2/blob/master/CHANGELOG.md)
* 3장, 7장 예제의 material 버전 변경 및 Angular CLI 버전도 명시적으로 최신화

## (2017-07-19) 70쪽 양방향 데이터 바인딩 맛보기

* Angular CLI가 1.1 이후에 변경된 내용이 발생하여 70쪽 예제를 실습을 위해 추가 작업이 필요합니다.
* src/app/app.module.ts 파일에 다음 링크와 같이 코드를 수정해야 합니다. [코드 링크](https://github.com/not-for-me/hb-angular-first/blob/17f66ce3129f1f948881d8553f3b024f184dba31/ch03/ng-welcome-msg-app/src/app/app.module.ts)
