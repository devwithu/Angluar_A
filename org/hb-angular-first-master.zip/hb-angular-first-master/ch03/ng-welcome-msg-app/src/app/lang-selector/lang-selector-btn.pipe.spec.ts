import { LangSelectorBtnPipe } from './lang-selector-btn.pipe';

describe('LangSelectorBtnPipe', () => {
  it('create an instance', () => {
    const pipe = new LangSelectorBtnPipe();
    expect(pipe).toBeTruthy();
  });
});
