import { InjectionToken } from '@angular/core';

export const API_URL_TOKEN = new InjectionToken<string>('API_URL');
export const API_VER_TOKEN = new InjectionToken<string>('API_VER');