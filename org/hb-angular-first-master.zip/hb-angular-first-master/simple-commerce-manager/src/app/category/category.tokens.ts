import { InjectionToken } from "@angular/core";

export const CAT_LIST_PAGE_SIZE = new InjectionToken<number>('CAT_LIST_PAGE_SIZE');
