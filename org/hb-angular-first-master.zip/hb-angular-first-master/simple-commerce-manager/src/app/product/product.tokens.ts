import { InjectionToken } from "@angular/core";
export const PROD_LIST_PAGE_SIZE = new InjectionToken<number>('PROD_LIST_PAGE_SIZE');
