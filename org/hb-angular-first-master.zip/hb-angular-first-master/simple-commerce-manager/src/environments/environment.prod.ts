export const environment = {
  production: true,
    firebase: {
    apiKey: "AIzaSyAyIdgL5mQTJY9pW1P14OmLVzw3chw41tU",
    authDomain: "hanbit-angular-first.firebaseapp.com",
    databaseURL: "https://hanbit-angular-first.firebaseio.com",
    projectId: "hanbit-angular-first",
    storageBucket: "hanbit-angular-first.appspot.com",
    messagingSenderId: "721541388016"
  }
};
